"""
core/agent_state.py — State Machine tường minh (Phase 10, Module 6)

Thay thế các biến boolean rải rác (is_thinking, is_reading, ...) bằng
một trạng thái duy nhất, rõ ràng và kiểm tra được.

Dùng:
    from core.agent_state import AgentState, StateMachine

    sm = StateMachine()
    sm.transition(AgentState.THINKING)
    print(sm.state)           # AgentState.THINKING
    sm.transition(AgentState.IDLE)

    # Kiểm tra nhanh
    if sm.is_idle(): ...
    if sm.is_in(AgentState.READING, AgentState.THINKING): ...
"""

from enum import Enum, auto
from core.logger import get_logger

logger = get_logger("agent_state")


class AgentState(Enum):
    """Các trạng thái chính của CognitiveEngine."""
    IDLE      = auto()   # Không làm gì, chờ input
    THINKING  = auto()   # Đang xử lý LLM call
    READING   = auto()   # Đang đọc sách trong background
    SLEEPING  = auto()   # Đang consolidate memory (sleep phase)
    SHUTDOWN  = auto()   # Đã shutdown, không nhận lệnh mới


# Transition table: từ state X có thể đến những state nào
_ALLOWED_TRANSITIONS: dict[AgentState, set] = {
    AgentState.IDLE:     {AgentState.THINKING, AgentState.READING, AgentState.SLEEPING, AgentState.SHUTDOWN},
    AgentState.THINKING: {AgentState.IDLE, AgentState.SHUTDOWN},
    AgentState.READING:  {AgentState.IDLE, AgentState.SHUTDOWN},
    AgentState.SLEEPING: {AgentState.IDLE, AgentState.SHUTDOWN},
    AgentState.SHUTDOWN: set(),  # Không đi đâu được sau khi shutdown
}


class StateMachine:
    """
    State machine nhỏ, thread-safe wrapper xung quanh AgentState.

    Ghi chú: StateMachine không dùng lock nội bộ — nếu dùng trong
    môi trường đa luồng, hãy bảo vệ bằng _ego_lock hoặc _memory_lock
    của CognitiveEngine.
    """

    def __init__(self, initial: AgentState = AgentState.IDLE):
        self._state = initial
        logger.info(f"StateMachine khởi tạo: {self._state.name}")

    @property
    def state(self) -> AgentState:
        return self._state

    def transition(self, new_state: AgentState) -> bool:
        """
        Chuyển state. Trả về True nếu thành công, False nếu transition không hợp lệ.
        Không raise exception — hệ thống tiếp tục hoạt động dù transition bị chặn.
        """
        allowed = _ALLOWED_TRANSITIONS.get(self._state, set())
        if new_state not in allowed:
            logger.warning(
                f"[STATE MACHINE] Transition bị chặn: {self._state.name} → {new_state.name} "
                f"(allowed: {[s.name for s in allowed]})"
            )
            return False
        logger.debug(f"[STATE MACHINE] {self._state.name} → {new_state.name}")
        self._state = new_state
        return True

    def force(self, new_state: AgentState):
        """Override trực tiếp, dùng khi cần recover từ lỗi."""
        logger.warning(f"[STATE MACHINE] FORCE override: {self._state.name} → {new_state.name}")
        self._state = new_state

    # ------- Helper predicates ------- #

    def is_idle(self) -> bool:
        return self._state == AgentState.IDLE

    def is_busy(self) -> bool:
        return self._state in (AgentState.THINKING, AgentState.READING, AgentState.SLEEPING)

    def is_in(self, *states: AgentState) -> bool:
        return self._state in states

    def is_shutdown(self) -> bool:
        return self._state == AgentState.SHUTDOWN

    def __repr__(self) -> str:
        return f"StateMachine({self._state.name})"
